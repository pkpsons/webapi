﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APM.Entity;

namespace APM.Repository.Interface
{
   public interface IUserRepository
    {
           User Create();
           User Save(User user);
           User Save(int id, User user);
           List<User> Retrieve();
    }
}
