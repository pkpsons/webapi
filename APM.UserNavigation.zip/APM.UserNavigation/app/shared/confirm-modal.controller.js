
'use strict';
define(['app'], function (app) {

    app.controller('ConfirmModalCtrl', ConfirmModalCtrl);


    function ConfirmModalCtrl($modalInstance, data) {
        /* jshint validthis: true */
        var vm = this;

        vm.cancel = cancel;
        vm.ok = ok;
        vm.properties = data;

        function cancel() {
            $modalInstance.dismiss();
        }

        function ok() {
            $modalInstance.close();
        }


    }

});


