﻿/// <reference path="Scripts/angular-resource.js" />
/// <reference path="users/edit-user.controller.js" />
/// <reference path="services/dataService.js" />
/// <reference path="common/userResource.js" />
/// <reference path="common/common.services.js" />

require.config({
    baseUrl: 'app',
    paths: {
        'angular': '/Directive/Scripts/angular',
    },
    shim: {
        //'blockUI': ['angular'],
        //'angular-translate' : ['angular'],
        //'angular-translate-loader-partial': ['angular'],
        //'angular-animate': ['angular']
    }
});

require(
    [
        'app',
        'main/mainController',
        'directive/employeeInfo',
        'directive/userInfoCard',
        'shared/confirm-modal.controller',
        'services/dialogs.service',
        'users/edit-user-controller',
        'common/common.services',
        'common/userResource',
       
    ]
    ,
    function () {
        angular.bootstrap(document, ['app']);
    }
    );