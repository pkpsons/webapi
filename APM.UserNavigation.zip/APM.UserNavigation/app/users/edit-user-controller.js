﻿'use strict';
define(['app'], function (app) {

	app.controller('EditUserCtrl', EditUserCtrl);

	EditUserCtrl.$inject = ['$modalInstance', 'data'];

	function EditUserCtrl($modalInstance, data) {
		var vm = this;
		vm.opened = false;
		vm.open = openDatePicker;
		vm.activate = activate;
		vm.cancel = cancel;
		vm.editableUser = angular.copy(data.userToEdit);
		vm.properties = data;
		vm.save = save;
		vm.title = (data.userToEdit ? 'Edit user' : 'Add New User');

		activate();


		function activate() {
		}

		function cancel() {
			$modalInstance.dismiss();
		}

		function save() {
		    vm.editableUser.dob = moment(vm.editableUser.dob).format('DD/MM/YYYY');
		    $modalInstance.close(vm.editableUser);
		}
		function openDatePicker($event) {
		    $event.preventDefault();
		    $event.stopPropagation();
		    vm.opened = true;
		}
	}
});
