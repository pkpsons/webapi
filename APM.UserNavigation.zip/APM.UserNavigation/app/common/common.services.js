﻿'use strict';
define(['app'], function (app) {

   app.constant("appSettings",
        {
            serverPath: "http://localhost:52293"
        });
});
