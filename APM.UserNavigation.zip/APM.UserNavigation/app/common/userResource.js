﻿'use strict';
define(['app'], function (app) {

    app.factory('userResource', ['$resource', '$q', userResource]);

    function userResource($resource, $q) {

        function getUser(route, method) {
            var deferred = $q.defer();

            var addr = ['http://localhost:52293//api//Users', route].join('/');
            $resource(addr)[method]()
            .$promise
                .then(function (data) {
                    deferred.resolve(data);
                })
                .catch(function (error) {
                    deferred.reject(error);
                });
            return deferred.promise;
        }

        return {
            getAllUsers: function () {
                return getUser('', 'query');
            },
            getSingleUser: function (id) {
                return getUser(id, 'get');
            }
        }
    }
});
//'get': {
//    headers: { 'Authorization': 'Bearer ' + currentUser.getProfile().token }
//},

//                'save': {
//    headers: { 'Authorization': 'Bearer ' + currentUser.getProfile().token }
//},

//                'update': {
//    method: 'PUT',
//    headers: { 'Authorization': 'Bearer ' + currentUser.getProfile().token }
//}