﻿
'use strict';
define(['app'], function (app) {

    app.directive('employeeInfo', [employeeInfo]);

    function employeeInfo() {
        return {
            templateUrl: "../app/template/employeeInfo.html",
            restrict: "E",
            controller: function ($modal, $scope, $routeParams, ngTableParams, dialogsService, userResource) {

                $scope.loading = true;
                $scope.users = [];
                $scope.usersTable = {};
                $scope.getAllUsers = function () {
                    userResource.getAllUsers().then(function (users) {
                        $scope.users = users;
                        $scope.usersTable = new ngTableParams({
                            page: 1,
                            count: 5
                        }, {
                            total: $scope.users.length,
                            getData: function ($defer, params) {
                                $scope.data = $scope.users.slice((params.page() - 1) * params.count(), params.page() * params.count());
                                $defer.resolve($scope.data);
                            }
                        });
                    })
                    .finally(function () {
                        $scope.loading = false;
                    });
                }
                $scope.getAllUsers();

                $scope.deleteEmployee = function (user) {
                    dialogsService.confirm('Are you sure you want to Delete this item?', 'Delete?', ['OK', 'Cancel'])
                        .then(function () {
                            for (var i = $scope.users.length - 1; i >= 0; i--) {
                                if ($scope.users[i].id == user.id) {
                                    $scope.users.splice(i, 1);
                                    $scope.usersTable.reload();
                                    //var index = $scope.users.indexOf(user);
                                    //$scope.users.splice(index, 1);
                                }
                            }
                            //$scope.$apply();
                            $scope.refresh();
                        });
                    }
                           
                     

                $scope.editEmployee = function (user) {
                    var modalInstance = $modal.open({
                        templateUrl: '../app/users/edit-user.html',
                        controller: 'EditUserCtrl',
                        controllerAs: 'vm',
                        resolve: {
                            data: function () {
                                return {
                                    userToEdit: user
                                };
                            }
                        }
                    });

                    modalInstance.result.then(function (result) {
                        if (user) {
                            angular.copy(result, user);
                            } else {
                            $scope.users.push(result);
                            }
                            initializeGroups();
                    });
                }
            }
        }
    }
});


