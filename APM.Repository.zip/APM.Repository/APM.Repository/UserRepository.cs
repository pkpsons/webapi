﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using Newtonsoft.Json;
using APM.Entity;
using APM.Repository.Interface;

namespace APM.Repository
{
    public class UserRepository:IUserRepository
    
    {
     
        /// <summary>
        /// Creates a new user with default values
        /// </summary>
        /// <returns></returns>
       public User Create()
        {
            User user = new User
            {
                dob = DateTime.Now
            };
            return user;
        }

        /// <summary>
        /// Retrieves the list of users.
        /// </summary>
        /// <returns></returns>
        public List<User> Retrieve()
         {
             var filePath = System.Web.HttpContext.Current.Server.MapPath(@"~/App_Data/users.json");

             var json = System.IO.File.ReadAllText(filePath);

             var users = JsonConvert.DeserializeObject<List<User>>(json);

             return users;
         }

        /// <summary>
        /// Saves a new user.
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public User Save(User user)
         {
             // Read in the existing users
             var users = this.Retrieve();

             // Assign a new Id
             var maxId = users.Max(p => p.id);
             user.id = maxId + 1;
             users.Add(user);

             WriteData(users);
             return user;
         }

        /// <summary>
        /// Updates an existing user
        /// </summary>
        /// <param name="id"></param>
        /// <param name="user"></param>
        /// <returns></returns>
        public User Save(int id, User user)
         {
             // Read in the existing users
             var users = this.Retrieve();

             // Locate and replace the item
             var itemIndex = users.FindIndex(p => p.id == user.id);
            
             if (itemIndex >= 0)
             {
                 users[itemIndex] = user;
             }
             else
             {
                 return null;
             }

             WriteData(users);
             return user;
         }

         bool WriteData(List<User> users)
         {
             // Write out the Json
             var filePath = System.Web.HttpContext.Current.Server.MapPath(@"~/App_Data/users.json");

             var json = JsonConvert.SerializeObject(users, Formatting.Indented);
             System.IO.File.WriteAllText(filePath, json);

             return true;
         }




       

        

        

       

     
    }
}
